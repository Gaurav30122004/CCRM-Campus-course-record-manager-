package edu.ccrm.service;
public class MaxCreditLimitExceededException extends Exception {
public MaxCreditLimitExceededException(String message) {
super(message);
}
}