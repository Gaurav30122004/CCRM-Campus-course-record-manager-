package edu.ccrm.service;
public class DuplicateEnrollmentException extends Exception {
public DuplicateEnrollmentException(String message) {
super(message);
}
}